#!/bin/bash
docker compose up -d
docker compose logs -f orchestrator

