# Documentation Bojemoi Orchestrator

## Installation

Voir [../README.md](../README.md)

## Configuration

Editer le fichier `.env` avec vos paramètres.

## Utilisation

### Via API
```bash
curl -X POST http://localhost:8000/deploy/vm/web-server-01
```

### Via CLI
```bash
python cli.py deploy-vm web-server-01
```

