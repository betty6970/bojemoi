import pytest

@pytest.fixture
def test_config():
    return {"test": True}

