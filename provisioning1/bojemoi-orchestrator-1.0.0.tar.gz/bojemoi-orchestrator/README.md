# Bojemoi Orchestrator

Orchestrateur de déploiement unifié pour infrastructure hybride.

## Installation Rapide
```bash
./scripts/install.sh
```

## Documentation

Voir le répertoire `docs/` pour la documentation complète.

## License

MIT License

